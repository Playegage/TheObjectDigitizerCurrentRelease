package basicClassTypes;

public class Triangle implements Shape {
	private Point basePoint = new Point();
	private Point verticalPoint = new Point();
	private Point sidePoint = new Point();
	
	public Triangle(Point base,Point vertical,Point side) {
		basePoint = base;
		verticalPoint = vertical;
		sidePoint = side;
	}
	
	public Point getBasePoint() {
		return basePoint;
	}

	public Point getVerticalPoint() {
		return verticalPoint;
	}

	public Point getSidePoint() {
		return sidePoint;
	}

	public String toString() {
		String output = basePoint.toString() + verticalPoint.toString() + sidePoint.toString();
		return output;
	}
}
