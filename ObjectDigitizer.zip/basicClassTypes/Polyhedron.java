package basicClassTypes;

public class Polyhedron implements Shape{
	private String points = "";
	private int numberOfPoints = 0;

	public Polyhedron(String pointsIn, int numberOfAngles){
		points = pointsIn;
		numberOfPoints = numberOfAngles;
	}

	public String getPoints() {
		return points;
	}
	
	public int getNumberOfPoints() {
		return numberOfPoints;
	}
}
