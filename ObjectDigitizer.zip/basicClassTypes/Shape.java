package basicClassTypes;

public interface Shape {

}
