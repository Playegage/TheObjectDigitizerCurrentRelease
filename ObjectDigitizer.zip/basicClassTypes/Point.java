package basicClassTypes;
import java.util.List;

public class Point {
	private float x = 0;
	private float y = 0;
	private float z = 0;
	
	public Point() {}
	
	public Point(float xIn, float yIn, float zIn) {
		x = xIn;
		y = yIn;
		z = zIn;
	}
	
	public Point(List<Double> list) {
		
	}
	
	public String toString() {
		String output = "";
		output = output + "[" + x + "," + y + "," + z +"] ";
		return output;
	}

	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}

	public float getZ() {
		return z;
	}

	public void setX(float x) {
		this.x = x;
	}

	public void setY(float y) {
		this.y = y;
	}

	public void setZ(float z) {
		this.z = z;
	}
	
}
