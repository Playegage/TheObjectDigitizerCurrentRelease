package dataManipulators;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import basicClassTypes.Point;

public class MatrixGenerator {
	private static int numberOfStepsForFullRotation = 400;//Actual value = 400. Two angle test value = 4. 
	private static int numberOfStepsToBeTakenEachTime = 2;
	private static int numberOfAngles = numberOfStepsForFullRotation/numberOfStepsToBeTakenEachTime;
	private static int numberOfVerticalSamples = 40;//Actual value = 40. Two angle test value = 35.
	private static int distanceBetweenSamples = 10;//Actual value = 10. Two angle test value = 5.
	private static int numberOfVerticalSamplesPerAngle[] = new int[numberOfAngles];
	
	public MatrixGenerator(){}
	
	public static List<List<List<Point>>> generateMatrix(File input) throws FileNotFoundException {
		Scanner s = new Scanner(input);
		List<Float> inputData = new ArrayList<Float>();
		List<List<List<Point>>> threeDimMatrix = new ArrayList<List<List<Point>>>();
		Point prevP = new Point();
		
		int numberOfPointsProcessed = 1;
		float pZ = 0;
		boolean topFound = false;
		for(int index = 0; index < numberOfAngles; index++) {
			numberOfVerticalSamplesPerAngle[index] = 0;
		}
		
		System.out.println("Filling Matrix");
		for(int angle = 0; angle < numberOfAngles; angle++) {
			List<List<Point>> angleHeightPoint = new ArrayList<List<Point>>();
			for(int height = 0; height < numberOfVerticalSamples; height++) {
				List<Point> heightPoint = new ArrayList<Point>();
				inputData = getValues(s);
				System.out.println("Got Values " + inputData.toString());
				Point p = generateDataPoint(inputData);
				if(height == 0) {
					prevP = p;
				}
				pZ = p.getZ()/distanceBetweenSamples;
				System.out.println("Got Converted Values "+ p.toString());
				System.out.println("Processed " + numberOfPointsProcessed +" Points");
				numberOfPointsProcessed++;
				heightPoint.add(p);
				angleHeightPoint.add(heightPoint);
				if(p.getX() > 0) {
					if(prevP.getX() > 0 && topFound == false) {	
						if(pZ > numberOfVerticalSamplesPerAngle[angle]) {
							numberOfVerticalSamplesPerAngle[angle] = (int) pZ;
						}
					}else {
						topFound = true;
					}
				}else if (p.getX() < 0){
					if(prevP.getX() < 0 && topFound == false) {	
						if(pZ > numberOfVerticalSamplesPerAngle[angle]) {
							numberOfVerticalSamplesPerAngle[angle] = (int) pZ;
						}
					}else {
						topFound = true;
					}
				}else if(p.getY() > 0) {
					if(prevP.getY() > 0 && topFound == false) {	
						if(pZ > numberOfVerticalSamplesPerAngle[angle]) {
							numberOfVerticalSamplesPerAngle[angle] = (int) pZ;
						}
					}else {
						topFound = true;
					}
				}else {
					if(prevP.getY() < 0 && topFound == false) {	
						if(pZ > numberOfVerticalSamplesPerAngle[angle]) {
							numberOfVerticalSamplesPerAngle[angle] = (int) pZ;
						}
					}else {
						topFound = true;
					}
				}
				prevP = p;
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) { 
					e.printStackTrace();
				}
			}
			topFound = false;
			System.out.println("Filled Matrix Column " + angle);
			threeDimMatrix.add(angleHeightPoint);			
		}
		System.out.println("Filled Matrix");
		return threeDimMatrix;
	}
	private static List<Float> getValues(Scanner s) throws FileNotFoundException{
		List<Float> list = new ArrayList<Float>();
		
		Float angle = (float)0.00;
		Float height = (float) 0.00;
		Float distance = (float)0.00;
		
		angle = s.nextFloat();
		height = s.nextFloat();
		distance = s.nextFloat();			
			
		list.add(angle);
		list.add(height);
		list.add(distance);
	
		return list;
	}
	private static Point generateDataPoint(List<Float> inputData) {
		DecimalFormat df = new DecimalFormat("0.00");
		float angle = 0;
		float angleRadians = 0;
		float height = 0;
		float distance = 0;
		float distanceToCenter = 219;
		String sx = "";
		String sy = "";
		float x = 0;
		float y = 0;
		float z = 0;
		
		int index = 0;
		
		angle = inputData.get(index);
		angleRadians = (float) Math.toRadians(angle);
		index++;
		height = inputData.get(index);
		index++;
		distance = distanceToCenter - inputData.get(index);
		index++;
		
		sx = df.format(distance * Math.cos(angleRadians));
		sy = df.format(distance * Math.sin(angleRadians));
		
		x=Float.valueOf(sx);
		y=Float.valueOf(sy);
		z = height;
			
		Point p = new Point(x,y,z);
		
		return p;
	}
	public int[] getNumberOfVerticalSamplesPerAngle() {
		return numberOfVerticalSamplesPerAngle;
	}
	public static int getNumberOfAngles() {
		return numberOfAngles;
	}
	public static int getDistanceBetweenSamples() {
		return distanceBetweenSamples;
	}	
	
}
