package dataManipulators;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class DataGatherer {
	public static String gatherData(String location, String port) {
		File output = new File(location + "rawData.txt");
		ProcessBuilder pb = new ProcessBuilder("plink", "-serial", port);
		
		List<String> dataValues = new ArrayList<String>();
	    String textValues = "";
	    int value = 0;
	    int waitingCount = 0;
		boolean running = true;
		boolean gotData = false;
		
		try {
			Process p = pb.start();
		    InputStream std = p.getInputStream ();
		    
		    while(running == true){		
			    Thread.sleep (1000);
			    textValues = "";
			    value = 0;
			    if (std.available () > 0) {
			        gotData = true;
			    	value = std.read ();
			        textValues = textValues + (char) value;
			        System.out.print (textValues);
			        while (std.available () > 0) {
			        	value = std.read ();
				        textValues = textValues + (char) value;
				        System.out.print(textValues);
			        }
			    }else if(waitingCount < 5){
			    	System.out.println("Waiting on data...");
			    	System.out.println("Moving on in " + (5 - waitingCount));
			    	waitingCount++;
			    }else if(gotData == true){
			    	System.out.println("Done Gathering Data.");
			    	running=false;
			    }else {
			    	System.out.println("");
			    	System.out.println("Please Press Button When Ready To Scan.");
			    	System.out.println("");
			    	waitingCount = 0;
			    }
			    dataValues.add(textValues);
		    }
		    System.out.println("Saving data.");
			saveDataValues(dataValues, output);
			System.out.println("Done Saving data.");
			p.destroy();
			std.close();
			
		}catch (Exception e) {
			    e.printStackTrace ();
		}
		return "Data Collection Complete";
	}
	
	private static void saveDataValues(List<String> dataValueList, File output) throws IOException {
		
		BufferedWriter out = new BufferedWriter(new FileWriter(output));
		String temp = "";
		try {
				
			for(int index = 0; index < dataValueList.size();index++) {
				temp = dataValueList.get(index);
				System.out.println(temp);
				out.write(temp);
				temp="";
			}
		}catch (IOException e) {
				System.out.println("I give up");
			}
		finally
		{ 
		   try{
		      if(out!=null)
			 out.close();
		   }catch(Exception ex){
		       System.out.println("Error in closing the BufferedWriter"+ex);
		    }
		}
	}
}