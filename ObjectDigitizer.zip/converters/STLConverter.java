package converters;
import java.io.IOException;

public class STLConverter {
	public static void convert(String desiredSaveLocation, String inputFileLocation) throws IOException {
		ProcessBuilder pb = new ProcessBuilder("C:\\Program Files\\OpenSCAD\\openscad.exe",
			     "-o", "" + desiredSaveLocation +".stl",
			     "-D", "quality=\"production\"",inputFileLocation);
		Process p = pb.start();
		try {
			p.waitFor();
		} catch (InterruptedException e) {
			System.out.println("Failed to perform STL conversion.");
		}
		p.destroy();
	}

}
