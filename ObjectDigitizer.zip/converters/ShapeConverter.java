package converters;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import basicClassTypes.Point;
import basicClassTypes.Polyhedron;
import basicClassTypes.Shape;
import basicClassTypes.Triangle;
import dataManipulators.MatrixGenerator;

public class ShapeConverter {
	public static List<Shape> getShapes(String location) throws FileNotFoundException{
		File input = new File(location + "rawData.txt");
		MatrixGenerator m= new MatrixGenerator();
		List<Shape> shapeList = new ArrayList<Shape>();
		
		shapeList = generateShapes(MatrixGenerator.generateMatrix(input), m.getNumberOfVerticalSamplesPerAngle(), MatrixGenerator.getNumberOfAngles(), MatrixGenerator.getDistanceBetweenSamples());
		return shapeList;
	}
	
	private static List<Shape> generateShapes(List<List<List<Point>>> threeDimMatrix, int numberOfVerticalSamples[], int numberOfAngles, int distanceBetweenSamples) {
		List<Shape> shapeList = new ArrayList<Shape>();
		Point basePoint = null;
		Point verticalPoint = null;
		Point sidePoint = null;
		String polyPointsTop = "";
		String polyPointsBottom = "";
		int count = 0;
		
		System.out.println("Generating Triangles");
		
		//Generate the upward facing triangles
		for(int indexAngle = 0; indexAngle < numberOfAngles; indexAngle++) {
			for(int indexHeight = 0; indexHeight < numberOfVerticalSamples[indexAngle]; indexHeight++) {
				basePoint = threeDimMatrix.get(indexAngle).get(indexHeight).get(0);
				if(indexHeight < numberOfVerticalSamples[indexAngle] - 1) {
					verticalPoint = threeDimMatrix.get(indexAngle).get(indexHeight+1).get(0);
				}else {
					verticalPoint = threeDimMatrix.get(indexAngle).get(indexHeight+1).get(0);
					polyPointsTop = polyPointsTop + verticalPoint.toString() + ",";
				}
				if(indexAngle == numberOfAngles - 1) {
					sidePoint = threeDimMatrix.get(0).get(indexHeight).get(0);
				}else {
					sidePoint = threeDimMatrix.get(indexAngle+1).get(indexHeight).get(0);
				}
				if((basePoint.getZ() + distanceBetweenSamples == verticalPoint.getZ()) || (basePoint.getZ() - distanceBetweenSamples == verticalPoint.getZ()) || (basePoint.getZ() + (distanceBetweenSamples * 2) == verticalPoint.getZ()) || (basePoint.getZ() - (distanceBetweenSamples * 2) == verticalPoint.getZ())) {
					if((basePoint.getZ() == sidePoint.getZ()) || (basePoint.getZ() == sidePoint.getZ()) || (basePoint.getZ() + distanceBetweenSamples == sidePoint.getZ()) || (basePoint.getZ() - distanceBetweenSamples == sidePoint.getZ()) || (basePoint.getZ() + (distanceBetweenSamples * 2) == sidePoint.getZ()) || (basePoint.getZ() - (distanceBetweenSamples * 2) == sidePoint.getZ())) {
						Triangle t = new Triangle(basePoint,verticalPoint,sidePoint);
						shapeList.add(t);
						count++;
					}
				}
				System.out.println("Generated " + count + " Triangles");
				basePoint = null;
				verticalPoint = null;
				sidePoint = null;
			}
		}
		//Generate the downward facing triangles
		for(int indexAngle = 0; indexAngle < numberOfAngles; indexAngle++) {
			for(int indexHeight = numberOfVerticalSamples[indexAngle]; indexHeight > 0; indexHeight--) {
				basePoint = threeDimMatrix.get(indexAngle).get(indexHeight).get(0);
				if(indexHeight > 1) {
					verticalPoint = threeDimMatrix.get(indexAngle).get(indexHeight-1).get(0);
				}else {
					verticalPoint = threeDimMatrix.get(indexAngle).get(indexHeight-1).get(0);
					polyPointsBottom = polyPointsBottom + verticalPoint.toString() + ",";
				}
				if(indexAngle == 0) {
					sidePoint = threeDimMatrix.get(numberOfAngles-1).get(indexHeight).get(0);
				}else {
					sidePoint = threeDimMatrix.get(indexAngle-1).get(indexHeight).get(0);
				}
				if((basePoint.getZ() + distanceBetweenSamples == verticalPoint.getZ()) || (basePoint.getZ() - distanceBetweenSamples == verticalPoint.getZ()) || (basePoint.getZ() + (distanceBetweenSamples * 2) == verticalPoint.getZ()) || (basePoint.getZ() - (distanceBetweenSamples * 2) == verticalPoint.getZ())) {
					if((basePoint.getZ() == sidePoint.getZ()) || (basePoint.getZ() == sidePoint.getZ()) || (basePoint.getZ() + distanceBetweenSamples == sidePoint.getZ()) || (basePoint.getZ() - distanceBetweenSamples == sidePoint.getZ()) || (basePoint.getZ() + (distanceBetweenSamples * 2) == sidePoint.getZ()) || (basePoint.getZ() - (distanceBetweenSamples * 2) == sidePoint.getZ())) {	
						Triangle t = new Triangle(basePoint,verticalPoint,sidePoint);
						shapeList.add(t);
						count++;
					}
				}
				System.out.println("Generated " + count + " Triangles");
				basePoint = null;
				verticalPoint = null;
				sidePoint = null;
			}
		}
		
		//Generate the top
		polyPointsTop= polyPointsTop.substring(0, polyPointsTop.length() - 1);
		Polyhedron top = new Polyhedron(polyPointsTop, numberOfAngles);
		System.out.println("Generated Top");
		shapeList.add(top);
		polyPointsTop = "";
		
		//Generate the bottom
		polyPointsBottom= polyPointsBottom.substring(0, polyPointsBottom.length() - 1);
		Polyhedron bottom = new Polyhedron(polyPointsBottom, numberOfAngles);
		System.out.println("Generated Bottom");
		shapeList.add(bottom);
		polyPointsBottom = "";
		
		System.out.println("Generated Shapes");
		
		return shapeList;
	}
}