package converters;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFileChooser;
import javax.swing.JFrame;

import basicClassTypes.Point;
import basicClassTypes.Polyhedron;
import basicClassTypes.Shape;
import basicClassTypes.Triangle;

public class ModelConverter {
	public static void convertToModel(String location, List<Shape> shapeList) {
		String outputFileLocation = location + "commandsV2.scad";
		File output = new File(outputFileLocation);
		
		List<String> commandList = null;
		try {
			commandList = generateModelScript(shapeList);
		} catch (InterruptedException e1) {
			System.out.println("Failed to generate model script.");
		}
		System.out.println("Got Model");
		System.out.println("Choose Save Location and Name");
		String desiredSaveLocation = chooseSaveLocation(location);
		//String desiredSaveLocation = "Enter Test Output Location Here";//For Testing
		
		try {
			saveModelScript(commandList, output);
			System.out.println("Saved Model");
			System.out.println("Converting Model To STL. This will take a long time.");
			STLConverter.convert(desiredSaveLocation, outputFileLocation);
		} catch (InterruptedException e1) {
			System.out.println("Failed to save model script, Interrupted");
			System.out.println("Try again");
		} catch (IOException e) {
			System.out.println("Failed to save model script");
			System.out.println("Try again");
		}
	}
	private static List<String> generateModelScript(List<Shape> shapeList) throws InterruptedException {
		List<String> commandList = new ArrayList<String>();
		List<String> pointList = getTrianglePointList(shapeList);
		System.out.println("Got Points");
		int number = 1;
		int numberOfPolyPoints = 0;
		String faceNumbers = "";
		
		String temp = "echo(version=version());";
		commandList.add(temp);
		temp = "";
		temp = temp + "union() {";
		commandList.add(temp);
		temp = "";
		temp = temp + "union() {";
		commandList.add(temp);
		temp = "";
		
		//generates the sides
		for(int index = 0; index < (pointList.size());) {
			temp =  temp +"ShapePoints" + number + " = [";
			
			temp = temp + pointList.get(index);
			System.out.println("Processed " + index + " Shapes");
			
			index++;
			
			temp = temp + "];";
			commandList.add(temp);
			temp = "";

			temp = temp + "polyhedron( ShapePoints" + number +", [[0,1,2]] );";
			commandList.add(temp);
			temp = "";
			number++;
		}
			
		//generates the top
		Polyhedron top = (Polyhedron) shapeList.get(shapeList.size()-2);
		numberOfPolyPoints = top.getNumberOfPoints();
		String points = "";

		points = points + top.getPoints();
		temp =  temp +"PolyhedronPoints1 = [";
		temp = temp + points;
		temp = temp + "];";
		commandList.add(temp);
		temp = "";
		
		for(int index = numberOfPolyPoints-1; index > 0; index--) {
			faceNumbers = faceNumbers + "," + index;
		}
		faceNumbers = "" + (numberOfPolyPoints-1) + faceNumbers;
		
		temp = "";
		temp = temp + "polyhedron( PolyhedronPoints1, [[" + faceNumbers +"]] );";
		commandList.add(temp);
		temp = "";
		temp = temp + "}";
		commandList.add(temp);
		temp = "";
		faceNumbers = "";
		
		//generates the bottom
		Polyhedron bottom = (Polyhedron) shapeList.get(shapeList.size()-1);
		numberOfPolyPoints = bottom.getNumberOfPoints();
		points = "";

		points = points + bottom.getPoints();
		temp =  temp +"PolyhedronPoints2 = [";
		temp = temp + points;
		temp = temp + "];";
		commandList.add(temp);
		temp = "";
		
		for(int index = 0; index < numberOfPolyPoints-1; index++) {
			faceNumbers = faceNumbers + index + ",";
		}
		faceNumbers = faceNumbers + (numberOfPolyPoints-1);
		
		temp = temp + "polyhedron( PolyhedronPoints2, [[" + faceNumbers +"]] );";
		
		commandList.add(temp);
		temp = "";
		temp = temp + "}";
		commandList.add(temp);
		temp = "";
		
		return commandList;
	}
	private static List<String> getTrianglePointList(List<Shape> shapeList) throws InterruptedException {
		List<String> pointList = new ArrayList<String>();
		Point basePoint = new Point();
		Point verticalPoint = new Point();
		Point sidePoint = new Point();
		
		String points = "";
		
		System.out.println(shapeList.size());
		Thread.sleep(1000);
        
		for(int index = 0; index < shapeList.size()-2;index++) {
			Triangle triangle = (Triangle) shapeList.get(index);
			basePoint = triangle.getBasePoint();
			verticalPoint = triangle.getVerticalPoint();
			sidePoint = triangle.getSidePoint();
			points = points + basePoint.toString() +"," + verticalPoint.toString() + "," + sidePoint.toString();
			pointList.add(points);
			points = "";
			System.out.println(index + " points found");
			Thread.sleep(1);
		}
		return pointList;
	}
	private static String chooseSaveLocation(String location) {
		JFrame parentFrame = new JFrame(); 
		JFileChooser fileChooser = new JFileChooser();
		String desiredSaveLocation = "";
		
		fileChooser.setDialogTitle("Specify where you would like to save your model");   
		int userSelection = fileChooser.showSaveDialog(parentFrame);
		 
		if (userSelection == JFileChooser.APPROVE_OPTION) {
		    File fileToSave = fileChooser.getSelectedFile();
		    desiredSaveLocation = desiredSaveLocation + fileToSave.getAbsolutePath();
		    System.out.println("Saving file at " + desiredSaveLocation);
		}
		else {
			desiredSaveLocation = desiredSaveLocation + location;
			System.out.println("Saving file at default location: " + desiredSaveLocation);
		}
		return desiredSaveLocation;
	}
	private static void saveModelScript(List<String> commandList, File output) throws IOException, InterruptedException {
		BufferedWriter out = new BufferedWriter(new FileWriter(output));
		String temp = "";
		try {
			for(int index = 0; index < commandList.size();index++) {
				temp = commandList.get(index);
				out.write(temp);
				out.write("\n");
				temp="";
				System.out.println(index + " commands saved");
				Thread.sleep(1);
			}
		}catch (IOException e) {
				System.out.println("I give up");
			}
		finally
		{ 
		   try{
		      if(out!=null)
			 out.close();
		   }catch(Exception ex){
		       System.out.println("Error in closing the BufferedWriter"+ex);
		    }
		}
	}	
}
