import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;

import basicClassTypes.Shape;
import converters.ModelConverter;
import converters.ShapeConverter;
import dataManipulators.DataGatherer;

public class ObjectDigitizerDriverV2 {

	public static void main(String[] args) {
		File me = new File("ObjectDigitizerDriverV2.java");
		String myLocation = me.getAbsolutePath();
		
		myLocation = myLocation.replace("ObjectDigitizerDriverV2.java", "");
		//for eclipse use only
		//myLocation = myLocation.concat("src\\main\\java\\");
		//for eclipse use only
		myLocation = myLocation.replace("\\", "\\\\");
		
		
		Scanner s = new Scanner(System.in);
		boolean running = true;
		boolean waiting = true;
		String port = "";
		
		System.out.println("Would you like to perform a scan?");
		System.out.print("Enter y for yes and n for no:");
		String choice = s.nextLine();
		//String choice = "y";//For Testing
		
		if(choice.compareTo("y")==0) {
			System.out.println("");
			System.out.println("Enter the name of serial port where the Object Digitizer is connected.");
			System.out.println("This can found when loading the code into the Arduino.");
			System.out.println("Example: COM3");
			port = s.nextLine();
			//port = "COM3";//For Testing
			System.out.println("");
			System.out.println("Ensure the scanner is plugged in and ");
			System.out.println("place the object to be scanned on the table.");
			System.out.println("Once ready push the button on the device to being the scan.");
			String ready = DataGatherer.gatherData(myLocation, port);
			//String ready = "Data Collection Complete";//For Testing
			
			while(waiting == true) {
				if(ready.compareTo("Data Collection Complete")==0) {
					waiting = false;
					performScan(s,myLocation);
				}else {
					System.out.print("Something went wrong. Restart me.");
				}
			}
		}else {
			running = false;
		}
		
		while(running == true) {
			System.out.println("");
			System.out.println("Would you like to perform another scan?");
			System.out.print("Enter y for yes and n for no:");
			choice = s.nextLine();
			
			if(choice.compareTo("y")==0) {
				waiting = true;
				System.out.println("");
				System.out.println("Once ready push the button on the device to being the scan.");
				String ready = DataGatherer.gatherData(myLocation, port);
				while(waiting == true) {
					if(ready.compareTo("Data Collection Complete")==0) {
						waiting = false;
						performScan(s,myLocation);
					}else {
						System.out.print("Something went wrong. Restart me.");
					}
				}
			}else {
				running = false;
			}
		}
		System.out.println("Closing Program");
		System.out.println("Remember to unplug the system.");
		System.out.println("Goodbye");
		s.close();
	}
	private static void performScan(Scanner s, String location) {
		List<Shape> shapeList = null;
				
		try {
			shapeList = ShapeConverter.getShapes(location);
			System.out.println("Got triangles");
		} catch (FileNotFoundException e1) {
			System.out.println("Failed to get triangles.");
		}
		ModelConverter.convertToModel(location, shapeList);
		System.out.println("STL Generated");
		System.out.println("Scan Complete");
	}
}
